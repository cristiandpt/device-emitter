package com.cristiandpt.device_emitter

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class DeviceEmitterApplicationTests {

	@Test
	fun contextLoads() {
	}

}
