package com.cristiandpt.device_emitter

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class DeviceEmitterApplication

fun main(args: Array<String>) {
	runApplication<DeviceEmitterApplication>(*args)
}
